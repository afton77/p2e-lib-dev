<?php $this->load->view('template_header') ?>
<h3>Email Anda telah kami prosess.</h3>
<h4>Harap tunggu email balasan dari kami.</h4>
<?php $this->load->view('template_menu'); ?>
<?php $this->load->view('template_footer') ?>
