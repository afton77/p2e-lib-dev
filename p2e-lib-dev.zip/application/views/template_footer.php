<!-- FOOTER -->
<footer class="footer navbar-fixed-bottom" id="footer" style="bottom: 0px; width: 100%; height: 60px; background-color: #000">
    <div class="" style="color: #FFF">
        <div class="" style="text-align: center; padding-top: 10px;">
          DOKINFO P2E - Widya Graha LIPI Lt. 5 Jl. Jend. Gatot Subroto No. 10 Jakarta Selatan - 
          Telp. +62 21 525 1542 Ext. 622<br />
          &COPY; Pusat Penelitian Ekonomi
        </div>
    </div>
</footer>

<script type="text/javascript">
    tinymce.init({
        selector: "textarea",
        theme: "modern",
        plugins: [
         "link image lists hr anchor"
        ]
    });
</script>