<?php $this->load->view('template_header') ?>
  
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="alert alert-danger">
        Maaf Anda tidak diperkenankan untuk akses halaman ini.
      </div>
    </div>
  </div>
</div>

<script>
  var myJavanTech = angular.module('myJavanTech', ['ui.bootstrap']);
</script>
<?php $this->load->view('template_menu') ?>
<?php $this->load->view('template_footer') ?>
  